#include "kernelrunner.h"

#include <stdexcept>
#include <thread>
#include <iostream>
#include <iomanip>
#include <map>
#include <sstream>

#define THREADS_PER_LANE 32

//#define SINGLE_QUEUE_PER_DEVICE
//#define FLUSH_ALL
//#define SKIP_MEM_TRANSFERS

#include "../../include/perfscope.h"

namespace argon2 {
namespace opencl {

#ifdef SINGLE_QUEUE_PER_DEVICE
std::map<const Device*, cl::CommandQueue*> s_queues;
#endif

enum {
    ARGON2_REFS_PER_BLOCK = ARGON2_BLOCK_SIZE / (2 * sizeof(cl_uint)),
};

struct index {
    uint32_t refSlot;
    uint32_t store;
    uint32_t storeSlot;
};

size_t KernelRunner::totalRefsSize() const {
    auto context = programContext->getContext();
    std::uint32_t passes = params->getTimeCost();
    std::uint32_t lanes = params->getLanes();
    std::uint32_t segmentBlocks = params->getSegmentBlocks();

    Type type = programContext->getArgon2Type();
    if ((type == ARGON2_I || type == ARGON2_ID) && (optParams.mode == PRECOMPUTE_SIMPLE)) {
        std::uint32_t segments =
            type == ARGON2_ID
            ? lanes * (ARGON2_SYNC_POINTS / 2)
            : passes * lanes * ARGON2_SYNC_POINTS;
        std::size_t refsSize = segments * segmentBlocks * sizeof(cl_uint) * 2;
        return refsSize;
    }
    else if (type == ARGON2_I &&
        optParams.mode == PRECOMPUTE) {
        if (sizeof(struct index) != (3 * sizeof(cl_uint))) {
            throw std::logic_error("Invalid index struct size");
        }
        return optParams.customIndexNbSteps * sizeof(struct index);
    }
    return 0;
}

void KernelRunner::setKernelsArgs() {
    std::uint32_t passes = params->getTimeCost();
    std::uint32_t lanes = params->getLanes();
    std::uint32_t segmentBlocks = params->getSegmentBlocks();

    kernel.setArg<cl::Buffer>(1, memoryBuffer);

    if (optParams.mode == PRECOMPUTE) {
        std::size_t shmemSize = THREADS_PER_LANE * sizeof(cl_uint) * 2;

        kernel.setArg<cl::Buffer>(2, refsBuffer);

        uint32_t nSteps = ARGON2_SYNC_POINTS * segmentBlocks;

        kernel.setArg<cl_uint>(3, nSteps);
        kernel.setArg<cl_uint>(4, optParams.customBlockCount);
    }
    else if (optParams.mode == PRECOMPUTE_SIMPLE) {
        kernel.setArg<cl::Buffer>(2, refsBuffer);
        kernel.setArg<cl_uint>(3, passes);
        kernel.setArg<cl_uint>(4, lanes);
        kernel.setArg<cl_uint>(5, segmentBlocks);
    }
    else {
        kernel.setArg<cl_uint>(2, passes);
        kernel.setArg<cl_uint>(3, lanes);
        kernel.setArg<cl_uint>(4, segmentBlocks);
    }
}

void KernelRunner::setupKernel(const Device *device) {
    static const char *KERNEL_NAMES[2][2] = {
        {
            "argon2_kernel_oneshot",
            "argon2_kernel_segment",
        },
        {
            "argon2_kernel_oneshot_precompute",
            "argon2_kernel_segment_precompute",
        }
    };

    static const char *KERNEL_PRECOMPUTED_INDEX = "argon2_kernel_oneshot_precomputedIndex";

    bool precompute = (optParams.mode == PRECOMPUTE_SIMPLE);
    const char* kernelName = KERNEL_NAMES[precompute][bySegment];

    if (optParams.mode == PRECOMPUTE) {
        // check that we use argon2I
        auto buildOptions =
            programContext->getProgram().getBuildInfo<CL_PROGRAM_BUILD_OPTIONS>(device->getCLDevice());
        std::ostringstream oss;
        oss << "-DARGON2_TYPE=" << argon2::ARGON2_I;
        if (buildOptions.find(oss.str()) == std::string::npos) {
            throw std::logic_error("PRECOMPUTE only supported with ARGON2_I");
        }

        // check that we have only 1 lane, 1 pass etc.
        if (bySegment || params->getLanes() > 1 || params->getTimeCost() > 1) {
            throw std::logic_error("PRECOMPUTE only supported with 1 lane, 1 pass and oneshot mode");
        }

        // use custom kernel
        kernelName = KERNEL_PRECOMPUTED_INDEX;
    }

    kernel = cl::Kernel(programContext->getProgram(), kernelName);

    setKernelsArgs();
}

KernelRunner::KernelRunner(const ProgramContext *programContext,
                           const Argon2Params *params, const Device *device,
                           std::uint32_t batchSize, bool bySegment, t_optParams opt)
    : programContext(programContext), params(params), batchSize(batchSize),
      bySegment(bySegment), optParams(opt)
#if REUSE_BUFFERS
    , blocksBufferSize(0)
    , refsBufferSize(0)
    , lastPrecomputeAddress(nullptr)
#endif
{
    auto context = programContext->getContext();
    cl_command_queue_properties props = CL_QUEUE_PROFILING_ENABLE;
#ifdef SINGLE_QUEUE_PER_DEVICE
    auto it = s_queues.find(device);
    if (it == s_queues.end()) {
        s_queues.insert(
            std::make_pair(
                device,
                new cl::CommandQueue(context, device->getCLDevice(), props)));
    }
    queue = s_queues[device];
#else
    queue = new cl::CommandQueue(context, device->getCLDevice(), props);
#endif

    initializeBuffers();
  
    setupKernel(device);
}

size_t totalBlocksSize(uint32_t nBlocks, uint32_t batchSize) {
    return nBlocks * batchSize * ARGON2_BLOCK_SIZE;
}

void KernelRunner::initializeBuffers() {
#if REUSE_BUFFERS
    auto context = programContext->getContext();
    
    // blocks
    size_t blocksSize = totalBlocksSize(getBlockCount(), batchSize);
    if (blocksBufferSize < blocksSize) {
        memoryBuffer = cl::Buffer(context, CL_MEM_READ_WRITE, blocksSize);
        blocksBufferSize = blocksSize;
    }

    // refs / index buffer
    size_t refsSize = totalRefsSize();
    if (refsSize && refsBufferSize < refsSize) {
        refsBuffer = cl::Buffer(context, CL_MEM_READ_WRITE, refsSize);
        refsBufferSize = refsSize;
        if (optParams.mode == PRECOMPUTE_SIMPLE) {
            precomputeRefs();
        }
    }

    if (optParams.mode == PRECOMPUTE && optParams.customIndex != lastPrecomputeAddress) {
        bool blocking = false;
        cl_int res = queue->enqueueWriteBuffer(
            refsBuffer,
            blocking,
            0,
            refsSize,
            optParams.customIndex,
            NULL,
            NULL);
        queue->finish();
        lastPrecomputeAddress = optParams.customIndex;
    }
#else
    // blocks
    auto context = programContext->getContext();
    size_t blocksSize = totalBlocksSize(getBlockCount(), batchSize);
    memoryBuffer = cl::Buffer(context, CL_MEM_READ_WRITE, blocksSize);

    // refs
    size_t refsSize = totalRefsSize();
    if (refsSize) {
        if (optParams.mode == PRECOMPUTE_SIMPLE) {
            refsBuffer = cl::Buffer(context, CL_MEM_READ_WRITE, refsSize);
            precomputeRefs();
        }
        else if (optParams.mode == PRECOMPUTE) {
            refsBuffer = cl::Buffer(context, CL_MEM_READ_ONLY, refsSize);
            bool blocking = false;
            cl_int res = queue->enqueueWriteBuffer(
                refsBuffer,
                blocking,
                0,
                refsSize,
                optParams.customIndex,
                NULL,
                NULL);
            queue->finish();
        }
    }
#endif
}

void KernelRunner::freeBuffers() {
    memoryBuffer = cl::Buffer();
    refsBuffer = cl::Buffer();
}

void KernelRunner::reconfigureArgon(
    const Device *device,
    const Argon2Params *newParams, 
    std::uint32_t newBatchSize,
    const t_optParams &newOptParams) {
    if (bySegment) {
        printf("reconfigureArgon not supported with bySegment mode !\n");
        exit(1);
    }

    params = newParams;
    batchSize = newBatchSize;
    optParams = newOptParams;

#if REUSE_BUFFERS
    initializeBuffers();
#else
    freeBuffers();
    initializeBuffers();
#endif

    setupKernel(device);
}

void KernelRunner::precomputeRefs()
{
    std::uint32_t passes = params->getTimeCost();
    std::uint32_t lanes = params->getLanes();
    std::uint32_t segmentBlocks = params->getSegmentBlocks();
    std::uint32_t segmentAddrBlocks =
            (segmentBlocks + ARGON2_REFS_PER_BLOCK - 1)
            / ARGON2_REFS_PER_BLOCK;
    std::uint32_t segments = programContext->getArgon2Type() == ARGON2_ID
            ? lanes * (ARGON2_SYNC_POINTS / 2)
            : passes * lanes * ARGON2_SYNC_POINTS;

    std::size_t shmemSize = THREADS_PER_LANE * sizeof(cl_uint) * 2;

    cl::Kernel kernel = cl::Kernel(programContext->getProgram(),
                                   "argon2_precompute_kernel");

    kernel.setArg<cl::LocalSpaceArg>(0, { shmemSize });
    kernel.setArg<cl::Buffer>(1, refsBuffer);
    kernel.setArg<cl_uint>(2, passes);
    kernel.setArg<cl_uint>(3, lanes);
    kernel.setArg<cl_uint>(4, segmentBlocks);

    cl::NDRange globalRange { THREADS_PER_LANE * segments * segmentAddrBlocks };
    cl::NDRange localRange { THREADS_PER_LANE };

    queue->enqueueNDRangeKernel(kernel, cl::NullRange, globalRange, localRange);
    queue->finish();
}

void KernelRunner::uploadToInputMemoryAsync(std::uint32_t jobId, const void* srcPtr) {
    std::size_t mappedSize = params->getLanes() * 2 * ARGON2_BLOCK_SIZE;
    std::size_t batchMemSize = getBlockCount() * ARGON2_BLOCK_SIZE;
    bool blocking = false;
    size_t offset = batchMemSize * jobId;
    size_t size = mappedSize;
#ifndef SKIP_MEM_TRANSFERS
    {
        PerfScope p("enqueueWriteBuffer");
        cl_int res = queue->enqueueWriteBuffer(
            memoryBuffer,
            blocking,
            offset,
            size,
            srcPtr,
            NULL,
            NULL);
    }
#endif
#ifdef FLUSH_ALL
    queue->flush();
#endif
}

void KernelRunner::fetchOutputMemoryAsync(std::uint32_t jobId, void* dstPtr) {
    std::size_t batchMemSize = getBlockCount() * ARGON2_BLOCK_SIZE;
    std::size_t mappedSize = static_cast<std::size_t>(params->getLanes()) * ARGON2_BLOCK_SIZE;
    std::size_t mappedOffset = batchMemSize * (jobId + 1) - mappedSize;
    bool blocking = false;
#ifndef SKIP_MEM_TRANSFERS
    {
        PerfScope p("enqueueReadBuffer");
        cl_int res = queue->enqueueReadBuffer(
            memoryBuffer,
            blocking,
            mappedOffset,
            mappedSize,
            dstPtr,
            NULL,
            NULL);
    }
#endif
#ifdef FLUSH_ALL
    queue->flush();
#endif
}

void KernelRunner::insertEndEventAndFlush() {
    queue->enqueueMarker(&end);

    cl::detail::errHandler(queue->flush(), "KernelRunner::resultsReady, flushing queue");
}

void KernelRunner::run(std::uint32_t lanesPerBlock, std::uint32_t jobsPerBlock)
{
    std::uint32_t lanes = params->getLanes();
    std::uint32_t passes = params->getTimeCost();

    if (bySegment) {
        if (lanesPerBlock > lanes || lanes % lanesPerBlock != 0) {
            throw std::logic_error("Invalid lanesPerBlock!");
        }
    } else {
        if (lanesPerBlock != lanes) {
            throw std::logic_error("Invalid lanesPerBlock!");
        }
    }

    if (jobsPerBlock > batchSize || batchSize % jobsPerBlock != 0) {
        throw std::logic_error("Invalid jobsPerBlock!");
    }

    // run the kernel
    cl::NDRange globalRange { THREADS_PER_LANE * lanes, batchSize };
    cl::NDRange localRange { THREADS_PER_LANE * lanesPerBlock, jobsPerBlock };

    std::size_t shmemSize = THREADS_PER_LANE * lanesPerBlock * jobsPerBlock * sizeof(cl_uint) * 2;
    kernel.setArg<cl::LocalSpaceArg>(0, { shmemSize });
    if (bySegment) {
        bool precomputeSimple = (optParams.mode == PRECOMPUTE_SIMPLE);
        for (std::uint32_t pass = 0; pass < passes; pass++) {
            for (std::uint32_t slice = 0; slice < ARGON2_SYNC_POINTS; slice++) {
                kernel.setArg<cl_uint>(precomputeSimple ? 6 : 5, pass);
                kernel.setArg<cl_uint>(precomputeSimple ? 7 : 6, slice);
                queue->enqueueNDRangeKernel(kernel, cl::NullRange,
                                           globalRange, localRange);
            }
        }
    } else {
        {
            PerfScope p("enqueueNDRangeKernel");
            queue->enqueueNDRangeKernel(kernel, cl::NullRange,
                globalRange, localRange);
        }
    }

#ifdef FLUSH_ALL
   queue->flush();
#endif
}

void KernelRunner::waitForResults() {
    {
        PerfScope p("end.wait()");
        end.wait();
    }
}

bool KernelRunner::resultsReady() {
    cl_int err = NULL;
    auto status = end.getInfo<CL_EVENT_COMMAND_EXECUTION_STATUS>(&err);
    cl::detail::errHandler(err, "KernelRunner::resultsReady");

    if (status == CL_COMPLETE) {
        return true;
    }
    else {
        return false;
    }
}

uint32_t KernelRunner::getBlockCount() const {
    if (optParams.customBlockCount)
        return optParams.customBlockCount;
    return params->getLanes() * params->getSegmentBlocks() * ARGON2_SYNC_POINTS;
}

size_t KernelRunner::getMemoryUsage() const {
    size_t tot = totalBlocksSize(getBlockCount(), batchSize);

    if (refsBuffer() != NULL) {
        tot += totalRefsSize();
    }
    return tot;
}

size_t KernelRunner::getMemoryUsedPerBatch() const {
    return getBlockCount() * ARGON2_BLOCK_SIZE;
}

} // namespace opencl
} // namespace argon2
