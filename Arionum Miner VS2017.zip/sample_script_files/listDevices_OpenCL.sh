#!/bin/bash
set -e
./arionum-opencl-miner -l
