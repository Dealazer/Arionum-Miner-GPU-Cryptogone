#!/bin/bash
set -e
./arionum-cuda-miner -l


