#!/bin/bash

set -e

rm -rf build
rm -rf CMakeFiles
rm -f CMakeCache.txt


